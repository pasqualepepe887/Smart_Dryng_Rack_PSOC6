#include "HCSR04.h"
#include"cyhal.h"
#include "cybsp.h"

#define TIMER_FREQ_HZ       1000000UL


cyhal_timer_t timer;
cyhal_timer_cfg_t timer_cfg = {

         .period = 50000,
         .is_continuous = true,
         .direction = CYHAL_TIMER_DIR_UP,
         .compare_value = 0xFFFFFFFF,
         .value = 0
};

uint32_t start, end, duration, distance;



void HCSR04_config(TRIGGER_Pin,ECHO_Pin){
    cyhal_gpio_init(TRIGGER_Pin, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, CYBSP_LED_STATE_OFF);
    cyhal_gpio_init(ECHO_Pin, CYHAL_GPIO_DIR_INPUT, CYHAL_GPIO_DRIVE_NONE,CYBSP_BTN_OFF);



     cyhal_timer_init(&timer, NC, NULL);
     cyhal_timer_configure(&timer, &timer_cfg);
     cyhal_timer_start(&timer);

}

int HCSR04_getdistance(TRIGGER_Pin,ECHO_Pin){
    cyhal_gpio_write(TRIGGER_Pin, 1);
    Cy_SysLib_DelayUs(10);
    cyhal_gpio_write(TRIGGER_Pin, 0);

    while (!cyhal_gpio_read(ECHO_Pin));
    start = cyhal_timer_read(&timer);

    while (cyhal_gpio_read(ECHO_Pin));
    end = cyhal_timer_read(&timer);
    duration = end - start;
    int distance = (duration * 34300) / (2 * TIMER_FREQ_HZ);

    return distance;
   }
