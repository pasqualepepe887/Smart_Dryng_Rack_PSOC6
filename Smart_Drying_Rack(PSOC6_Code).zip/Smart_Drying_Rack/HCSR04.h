/*
 * HCSR04.h
 *
 *  Created on: 9 ago 2023
 *      Author: pasquale
 */

#ifndef HCSR04_H_
#define HCSR04_H_

#define TIMER_FREQ_HZ       1000000UL
extern char TRIGGER_Pin;
extern char ECHO_Pin;

extern void HCSR04_config();
extern int HCSR04_getdistance();


#endif /* HCSR04_H_ */
